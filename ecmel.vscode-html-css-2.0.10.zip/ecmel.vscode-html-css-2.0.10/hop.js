function validateForm() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (!email || !password || !confirmPassword) {
        alert("All fields are required.");
        return false;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }
    if (password.length < 6) {
        alert("Password must be at least 6 characters long.");
        return false;
    }
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }
    return true;
}

// Accordion Functionality
const faqQuestions = document.querySelectorAll('.faq-question');
const faqHeader = document.querySelector('.faq-header'); 

faqHeader.addEventListener('click', () => {
    faqQuestions.forEach(question => {
        const answer = question.nextElementSibling;
        answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
    });
});

faqQuestions.forEach(question => {
    question.addEventListener('click', () => {
        const answer = question.nextElementSibling;
        answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
    });
});

// Popup Form Functionality
const popupButton = document.getElementById('popup-button');
const popupForm = document.getElementById('popup-form');
const closePopup = document.getElementById('close-popup');

popupButton.addEventListener('click', () => {
    popupForm.style.display = 'block';
});

closePopup.addEventListener('click', () => {
    popupForm.style.display = 'none';
});

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

// Display Current Date and Time
function updateDateTime() {
    const now = new Date();
    const options = { month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
    document.getElementById('date-time').textContent = now.toLocaleString(undefined, options);
}

updateDateTime();
setInterval(updateDateTime, 1000); 

document.querySelector('#changeTextBtn').addEventListener('click', function() {
    document.querySelector('#message').textContent = 'The cougar is the fourth largest feline in the world and the second largest in the Americas; The only animals larger than her are the tiger, the lion and the jaguar. This cat reaches a length of 100-180 cm with a tail length of 60-75 cm, a height at the withers of 60-90 cm and a weight of up to 105 kg (males). Typically, a normal male of the large subspecies weighs 60-80 kg.';
});

document.addEventListener('DOMContentLoaded', () => {
    const themeToggleBtn = document.querySelector('#themeToggleBtn');

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', function() {
            document.body.classList.toggle('night-mode');
            const isNightMode = document.body.classList.contains('night-mode');
            localStorage.setItem('night-mode', isNightMode);
        });
    }

    const isNightMode = localStorage.getItem('night-mode') === 'true';
    if (isNightMode) {
        document.body.classList.add('night-mode');
    }
});

const thumbnails = document.querySelectorAll('.thumbnail');
thumbnails.forEach(thumbnail => {
    thumbnail.addEventListener('click', function() {
        document.querySelector('#mainImage').src = thumbnail.src;
    });
});

const user = {
    name: 'Nurkhan',
    greet: function() {
        return `Hello, ${this.name}!`;
    }
};
  
const items = ['Lion', 'Tiger', 'lynx'];
items.forEach(item => {
  const li = document.createElement('li');
  li.textContent = item;
  document.getElementById('itemList').appendChild(li);
});

const audio = document.getElementById('sound')
const playPauseBtn = document.getElementById('playPauseBtn');
const progressBar = document.getElementById('progressBar');
const currentTimeDisplay = document.getElementById('currentTime');
const totalTimeDisplay = document.getElementById('totalTime');
const muteBtn = document.getElementById('muteBtn');
const volumeControl = document.getElementById('volumeControl');

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    let formattedSeconds;
    if (remainingSeconds < 10) {
        formattedSeconds = '0' + remainingSeconds;
    } else {
        formattedSeconds = remainingSeconds.toString();
    }
    return minutes + ':' + formattedSeconds;
}

playPauseBtn.addEventListener('click', function() {
    if(audio.paused) {
        audio.play();
        playPauseBtn.textContent = 'Pause';
    }
    else {
        audio.pause();
        playPauseBtn.textContent = 'Play';
    }
});

audio.addEventListener('timeupdate', function() {
    progressBar.value = (audio.currentTime / audio.duration) * 100;
    currentTimeDisplay.textContent = formatTime(audio.currentTime);
    totalTimeDisplay.textContent = formatTime(audio.duration);
});

progressBar.addEventListener('input', function() {
    const seekTime = (progressBar.value / 100) / audio.duration;
    audio.currentTime = seekTime;
});

muteBtn.addEventListener('click', function() {
    audio.muted = !audio.muted;
    muteBtn.textContent = audio.muted ? 'Unmute' : 'Mute';
});

volumeControl.addEventListener('input', function() {
    audio.volume = volumeControl.value;
});

audio.addEventListener('loadedmetadata', function() {
    totalTimeDisplay.textContent = formatTime(audio.duration);
});

document.getElementById('animateBox').addEventListener('click', function() {
    const box = document.getElementById('box');
    
    box.style.transform = 'translateX(100px)';
    
    setTimeout(function() {
        box.style.transform = 'translateX(0px)';
    }, 1000); 
});

document.addEventListener('DOMContentLoaded', () => {
    const savedUser = localStorage.getItem('username');
    const savedTheme = localStorage.getItem('theme');
    const savedFilter = localStorage.getItem('filter');

    if (savedUser) {
        document.getElementById('user-name').innerText = savedUser;
        document.getElementById('login-container').style.display = 'none';
        document.getElementById('user-container').style.display = 'block';
    }

    if (savedTheme) {
        document.body.classList.add(savedTheme);
    }

    if (savedFilter) {
        document.getElementById('filter').value = savedFilter;
    }
});

function login() {
    const username = document.getElementById('username').value;
    if (username) {
        localStorage.setItem('username', username);
        document.getElementById('user-name').innerText = username;
        document.getElementById('login-container').style.display = 'none';
        document.getElementById('user-container').style.display = 'block';
    }
}

function logout() {
    localStorage.removeItem('username');
    document.getElementById('login-container').style.display = 'block';
    document.getElementById('user-container').style.display = 'none';
}

function savedText() {
    const saveText = document.getElementById('sText').value;
    localStorage.setItem('sText', saveText);
}

document.addEventListener('DOMContentLoaded', () => {
    const savedText = localStorage.getItem('sText');
    if (savedText) {
        document.getElementById('sText').value = savedText;
    }
});

function applyFilter() {
    const filterValue = document.getElementById('filter').value;
    const sections = document.querySelectorAll('section');

    sections.forEach(section => {
        if (filterValue === 'choose') {
            section.style.display = 'block';
        } else if (section.id === filterValue) {
            section.style.display = 'block';
        } else {
            section.style.display = 'none';
        }
    });
}

  


