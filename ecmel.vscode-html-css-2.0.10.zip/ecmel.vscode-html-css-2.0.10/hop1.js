// Проверка, если пользователь уже вошел
document.addEventListener('DOMContentLoaded', () => {
    const savedUser = localStorage.getItem('username');
    const savedTheme = localStorage.getItem('theme');
    const savedFilter = localStorage.getItem('filter');

    if (savedUser) {
        document.getElementById('user-name').innerText = savedUser;
        document.getElementById('login-container').style.display = 'none';
        document.getElementById('user-container').style.display = 'block';
    }

    if (savedTheme) {
        document.body.classList.add(savedTheme);
    }

    if (savedFilter) {
        document.getElementById('filter').value = savedFilter;
    }
});

function login() {
    const username = document.getElementById('username').value;
    if (username) {
        localStorage.setItem('username', username);
        document.getElementById('user-name').innerText = username;
        document.getElementById('login-container').style.display = 'none';
        document.getElementById('user-container').style.display = 'block';
    }
}

function logout() {
    localStorage.removeItem('username');
    document.getElementById('login-container').style.display = 'block';
    document.getElementById('user-container').style.display = 'none';
}

function toggleTheme() {
    if (document.body.classList.contains('dark-mode')) {
        document.body.classList.replace('dark-mode', 'light-mode');
        localStorage.setItem('theme', 'light-mode');
    } else {
        document.body.classList.replace('light-mode', 'dark-mode');
        localStorage.setItem('theme', 'dark-mode');
    }
}

function saveFilter() {
    const filterValue = document.getElementById('filter').value;
    localStorage.setItem('filter', filterValue);
}
